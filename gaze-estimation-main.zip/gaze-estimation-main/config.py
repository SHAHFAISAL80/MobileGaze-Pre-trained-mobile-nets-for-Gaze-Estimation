data_config = {
    "gaze360":
        {
            "bins": 90,
            "binwidth": 4,
            "angle": 180  # angle range
        },
    "mpiigaze":
        {
            "bins": 28,
            "binwidth": 3,
            "angle": 42  # angle range
        }

}